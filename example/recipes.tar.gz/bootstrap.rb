sleep 30
execute "echo #{node['message'].shellescape}"
