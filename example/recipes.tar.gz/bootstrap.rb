execute "echo #{node['message'].shellescape}"
